
const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  
email:{
  type:String,
  required:true
},
 password:{
  type:String,
  required:true
},
name: {
    type: String,
    required: true,
  },
  gender: {
    type: String
},
age: {
    type: Number,
    required: true
},
location:{
    type:String,
    required:true
},
hobbies:[String]
});

module.exports = mongoose.model("User", UserSchema);


// /*
// {
// "name":"raghav",
// "age":"21",
// "gender":"male",
// "location":"chandigarh",
// "hobbies":["music","swimming"]
// }


// */
