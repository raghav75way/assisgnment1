const router = require("express").Router();
const {registerController, loginController} = require("./controllers/User");


router.get("/", (req, res) => {
  res.send("creating a maach finder application")
});

router.post("/register", registerController);
router.post("/login",loginController);


module.exports = router;
