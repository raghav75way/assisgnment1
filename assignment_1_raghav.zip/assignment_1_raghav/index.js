const express = require("express");
const router = require("./router");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");
const bodyParser = require('body-parser');

dotenv.config();

const PORT = 8000;
const app = express();

app.use(router);
app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true,}),);

mongoose.connect(process.env.MONGODB_URL)
    .then(() => {
      console.log('Connected to database !!');
    })
    .catch((err)=>{
      console.log('Connection failed !!'+ err.message);
    });


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.listen(PORT, async () => {
  console.log(`server up on port ${PORT}`);
});
